﻿/*
 * Kent Je'Von
 * CSC-153
 * 2/5/2020
 * This program will display options from a menu for the user to store information and display it all later
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = new string[5];
            string[] phones = new string[5];
            List<string> ages = new List<string>();
            string choice;

            Console.WriteLine("Employees");
            do
            { //The menu for the program to loop back when you enter 
                Console.WriteLine("Menu");
                Console.WriteLine("1. Enter employee's name.");
                Console.WriteLine("2. Enter employee's phone number.");
                Console.WriteLine("3. Enter employee's age.");
                Console.WriteLine("4. Display employee's information.");
                Console.WriteLine("5. Display average age of employees.");
                Console.WriteLine("6. Exit");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.WriteLine("What is the employee's name?");
                        for (int x = 0; x < names.Length; x++)
                        {
                            names[x] = (Console.ReadLine());
                        }
                        for (int x = 0; x < names.Length; x++)
                        {
                            Console.WriteLine("The names of the employee" + names[x]);
                        }
                        break;
                    case "2":
                        Console.WriteLine("WHat is the employee's phone number?");
                        for (int y = 0; y < phones.Length; y++)
                        {
                            phones[y] = (Console.ReadLine());
                        }
                        for (int y = 0; y < phones.Length; y++)
                        {
                            Console.WriteLine("The phone numbers of the employee" + phones[y]);
                        }
                        break;
                    case "3":
                        Console.WriteLine("What is the employee's age?");
                        for (int z = 0; z < ages.Count; z++)
                        {
                            ages.Add(Console.ReadLine());
                        }
                        for (int z = 0; z < ages.Count; z++)
                        {
                            Console.WriteLine(ages[z]);
                        }
                        break;
                    case "4":
                        for (int x = 0; x < names.Length; x++)
                        {
                            Console.WriteLine("Name:" + names[x]);
                        }
                        for (int y = 0; y < phones.Length; y++)
                        {
                            Console.WriteLine("Phone Number:" + phones[y]);
                        }
                        for (int z = 0; z < ages.Count; z++)
                            Console.WriteLine("Age:" + ages[z]);
                        break;
                    case "5":
                        for (int z = 0; z < ages.Count; z++)
                        {
                            Console.WriteLine(ages[z]);
                        }
                        int sum1 = 0;
                        for (int z = 0; z < ages.Count; z++)
                        {
                            sum1 += ages[z];
                        }
                        int average = sum1 / ages.Count;
                        Console.WriteLine("The sum of the ages are: " + sum1);
                        Console.WriteLine("The average of the ages is: " + average);
                        Console.ReadLine();
                        break;
                    case "6":
                        break;
                    default:
                        Console.WriteLine("Not one of the options to choose from.");
                        break;
                }
                Console.WriteLine("Press the ENTER key to continue...");
                Console.ReadLine();
                Console.WriteLine();
            } while (choice != "6");
        }
    }
}
