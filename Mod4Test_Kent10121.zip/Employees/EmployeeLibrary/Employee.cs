﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields
        private string _name;
        private string _phoneNum;
        private int _age;

        // Constructors
        public Employee()
        {
            Name = "No Name";
            PhoneNumber = "No PhoneNum";
            Age = 0;
        }
        // Custom Constructor
        public Employee(string name, string phoneNum, int age)
        {
            Name = name;
            PhoneNumber = phoneNum;
            Age = age;
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string PhoneNumber
        {
            get
            {
                return _phoneNum;
            }
            set
            {
                _phoneNum = value;
            }
        }
        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
    }
}
