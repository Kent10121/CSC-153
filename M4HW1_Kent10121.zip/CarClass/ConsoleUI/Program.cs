﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            ClassLibrary.Car car = new ClassLibrary.Car();
            do
            {
                Console.WriteLine(ClassLibrary.StandardMessages.Menu());

                switch (Console.ReadLine())
                {
                    case "1":
                        car = ClassLibrary.BuildCar.BuildACar(car);
                        Console.WriteLine(ClassLibrary.StandardMessages.ShowCar(car));
                        break;
                    case "2":
                        car.Accelerate();
                        Console.WriteLine($"Your car is traveling at {car.Speed} mph");
                        break;
                    case "3":
                        car.Brake();
                        Console.WriteLine($"Your car is traveling at {car.Speed} mph");
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.StandardMessages.DisplayChoiceError());
                        break;
                }
                Console.WriteLine("Press ENTER key to continue...");
                Console.ReadLine();
            } while (exit == false);
        }
    }
}
