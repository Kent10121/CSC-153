﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string Menu()
        {
            return "1. Create a car\n2. Accelerate\n3. Brake\n4. Exit";
        }
        public static string ShowCar(Car yourCar)
        {
            return $"Car Year - {yourCar.Year}, Car Make - {yourCar.Make}";
        }
        public static string DisplayChoiceError()
        {
            return "Invalid Choice!";
        }
    }
}
