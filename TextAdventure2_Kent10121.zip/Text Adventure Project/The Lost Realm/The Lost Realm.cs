﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Lost_Realm
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] rooms = new string[] { "Arealia-Town", "Woods", "Dungeon Entrance", "Eerie Room", "Foggy Room" };
            string[] weapons = new string[] { "Handcrafted Axe", "Wooden Mace", "Wooden Bow", "Magical Staff" };
            string[] potions = new string[] { "Potion of Healing", "Potion of Mana" };
            string[] treasures = new string[] { "Golden Handclaw", "Titanium Titan", "Goblin Golden Eye" };
            List<string> items = new List<string>() { "Fur", "Gold Coins", "Wolf Meat", "Arrows" };
            List<string> mobs = new List<string>() { "Wolf", "Witch", "Goblin", "Troll", "Merchant" };

            Console.WriteLine("Welcome to The Lost Realm");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Main Menu");
            int choice = 1;

            while (choice <= 6)
            {
                Console.WriteLine("1. Display Rooms");
                Console.WriteLine("2. Display Weapoms");
                Console.WriteLine("3. Display Potions");
                Console.WriteLine("4. Display Treasures");
                Console.WriteLine("5. Display Items");
                Console.WriteLine("6. Display Mobs");
                Console.WriteLine("7. Exit");
            }
            switch(int)
            { }
            Console.ReadLine();
        }
    }
}
