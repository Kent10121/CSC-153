﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Lost_Realm
{
    public static class Menu
    {
        public static void MainMenu()
        {
            string[] rooms = new string[] { "Arealia-Town", "Woods", "Dungeon Entrance", "Eerie Room", "Foggy Room" };
            string[] weapons = new string[] { "Handcrafted Axe", "Wooden Mace", "Wooden Bow", "Magical Staff" };
            string[] potions = new string[] { "Potion of Healing", "Potion of Mana" };
            string[] treasures = new string[] { "Golden Handclaw", "Titanium Titan", "Goblin Golden Eye" };
            List<string> items = new List<string>() { "Fur", "Gold Coins", "Wolf Meat", "Arrows" };
            List<string> mobs = new List<string>() { "Wolf", "Witch", "Goblin", "Troll", "Merchant" };
            string choice;
            Console.WriteLine("Welcome to The Lost Realm");
            Console.WriteLine("-------------------------");
             do
             {
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Display Rooms");
                Console.WriteLine("2. Display Weapons");
                Console.WriteLine("3. Display Potions");
                Console.WriteLine("4. Display Treasures");
                Console.WriteLine("5. Display Items");
                Console.WriteLine("6. Display Mobs");
                Console.WriteLine("7. Exit");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        foreach(string room in rooms)
                        {
                            Console.WriteLine(room);
                        }
                        break;
                    case "2":
                        foreach (string weapon in weapons)
                        {
                            Array.Sort(weapons);
                            Console.WriteLine(weapon);
                        }
                        break;
                    case "3":
                        foreach (string potion in potions)
                        {
                            Console.WriteLine(potion);
                        }
                        break;
                    case "4":
                        foreach (string treasure in treasures)
                        {
                            Console.WriteLine(treasure);
                        }
                        break;
                    case "5":
                        foreach (string item in items)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case "6":
                        foreach (string mob in mobs)
                        {
                            Console.WriteLine(mob);
                        }
                        break;
                    case "7":
                        break;
                    default:
                        Console.WriteLine("Not a valid choice.");
                        break;
                }
                Console.Write("Press the ENTER key to continue...");
                Console.ReadLine();
                Console.WriteLine();
             } while (choice != "7");
        }
    }
}
