﻿/**
 * 3/1/2020
 * CSC 153
 * Kent Je'Von
 * This program will show the movement 
 * of North and South and the hit point of your attack
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Lost_Realm
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] rooms = new string[] { "Arealia-Town", "Woods", "Dungeon Entrance", "Eerie Room", "Foggy Room" };
            List<string> mobs = new List<string>() { "Wolf", "Witch", "Goblin", "Troll", "Merchant" };
            string choice;
            Console.WriteLine("Welcome to The Lost Realm");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Main Menu");
            do
            {

                Console.WriteLine("1. Move North");
                Console.WriteLine("2. Move South");
                Console.WriteLine("3. Attack");
                Console.WriteLine("4. Exit");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                    case "north":
                    case "North":
                        {
                            GoNorth(ref rooms);
                        }
                        break;
                    case "2":
                    case "south":
                    case "South":
                        {
                            GoSouth(ref rooms);
                        }
                        break;
                    case "3":
                    case "attack":
                    case "Attack":
                        {
                            ToAttack(ref mobs);
                        }
                        break;
                    case "4":
                        break;
                    default:
                        Console.WriteLine("Not a valid choice.");
                        break;
                }
                Console.Write("Press the ENTER key to continue...");
                Console.ReadLine();
                Console.WriteLine();
            } while (choice != "4");
        }
        public static void GoNorth(ref string[] rooms)
        {
            int index = 0;
            if (index + 1 < rooms.Length)
            {
                index++;
                Console.WriteLine($"You moved to {rooms[index]}");
            }
            if (index > rooms.Length)
            {
                Console.WriteLine("Can't go further more");
            }
        }
        public static void GoSouth(ref string[] rooms)
        {
            int index = 1;
            if (index - 1 < rooms.Length)
            {
                index--;
                Console.WriteLine($"You moved to {rooms[index]}");
            }
        }
        public static void ToAttack(ref List<string> mobs)
        {
            Random rand = new Random();
            Console.Write($"You have a hit point of ");
            Console.Write(rand.Next(1, 20));
            Console.WriteLine($" o {mobs[0]}");
            return;
        }
    }
}