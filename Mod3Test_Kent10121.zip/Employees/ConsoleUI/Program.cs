﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * Kent Je'Von 
 * CSC - 153
 * 2/10/2020
 */
namespace ConsoleUI
{
    class Program
    {
        
        static void Main(string[] args)
        {
            // Input for the user and for the loop
            string input;
            bool exit = false;

            // Process 
            do
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                // User's input
                input = Console.ReadLine();

                // Switch to the process
                switch (input)
                {
                    case "1":
                        // A method in the library for the name
                        Console.WriteLine(EmployeeLibrary.StandardMessages.EnterName());
                        break;
                    case "2":
                        // A method in the library for the phone number
                        Console.WriteLine(EmployeeLibrary.StandardMessages.EnterNumber());
                        break;
                    case "3":
                        Console.WriteLine(EmployeeLibrary.StandardMessages.EnterAge());
                        break;
                    case "4":
                        Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee());
                        break;
                    case "5":
                        Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayAverageAge());
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice!");
                        break;

                }
            } while (exit == false);
        }
    }
}
