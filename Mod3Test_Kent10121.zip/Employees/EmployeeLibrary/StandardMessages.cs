﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string DisplayUserInput(string prompt)
        {
            Console.WriteLine(prompt);
            return Console.ReadLine();
        }
        public static string DisplayMenu()
        {
            return "1.Enter employee's name. \n2.Enter employee's phone number. \n3.Enter employee's age. \n4.Display employee information. \n5.Display average age of employees. \n6.Exit";
        }
        public static string EnterName()
        {
            string input;
            int nameIndex = 0;
            const int SIZE = 5;
            string[] employeeNames = new string[SIZE];
            Console.WriteLine("Enter employee's name: ");
            input = Console.ReadLine();
            employeeNames[nameIndex] = input;
            nameIndex++;
            return "";
        }
        public static string EnterNumber()
        {
            string input;
            int phoneIndex = 0;
            const int SIZE = 5;
            string[] employeePhone = new string[SIZE];
            Console.WriteLine("Enter employee's number: ");
            input = Console.ReadLine();
            employeePhone[phoneIndex] = input;
            phoneIndex++;
            return "";
        }
        public static string EnterAge()
        {
            string input;
            List<int> employeeAge = new List<int>();
            int number = 0;
            Console.WriteLine("Enter employee's ages: ");
            input = Console.ReadLine();
            if (int.TryParse(input, out number))
            {
                employeeAge.Add(number);
            }
            else
            {
                Console.WriteLine("Not a valid number");
            }
            return "";
        }
        public static string DisplayEmployee()
        {
            const int SIZE = 5;
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();
            for (int index = 0; index < employeeAge.Count; index++)
            {
                Console.WriteLine($"Employee Name - {employeeNames[index]}");
                Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                Console.WriteLine($"Employee Age - {employeeAge[index].ToString()}");
                return "";
            }
            return"";
        }
        public static string DisplayAverageAge()
        {
            List<int> employeeAge = new List<int>();
            Console.WriteLine(employeeAge.Average());
            return "";
        }
    }
}
