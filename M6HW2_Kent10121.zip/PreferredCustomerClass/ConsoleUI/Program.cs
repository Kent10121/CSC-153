﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerClassLibrary;

/**
* 4/24/2020
* CSC 153
* Je'Von Kent
* This program displays a customer spent amount
* and displays the discount they earned for 
* future purchases
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            PreferredCustomer customer1 = new PreferredCustomer();
            customer1.Name = "Jim";
            customer1.Address = "143 Lakeway Ave.";
            customer1.Telephone = "9106452347";
            customer1.CustomerNum = 984;
            customer1.MailingList = true;
            customer1.SpentAmount = 1745;

            // Show the customer information
            Console.WriteLine(StandardMessages.ShowCustomer(customer1));

            // The information on how much they spent and earned a discount
            Console.WriteLine($"The customer spent ${customer1.SpentAmount} and earned a {customer1.GetDiscountPercent()} percent discount");
            Console.ReadLine();
        }     
    }
}
