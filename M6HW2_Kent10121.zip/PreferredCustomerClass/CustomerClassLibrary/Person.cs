﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerClassLibrary
{
    public class Person
    {
        // Fields
        private string _name;
        private string _address;
        private string _telephone;

        //Constructors
        public Person()
        {
            Name = "No Name";
            Address = "No Address";
            Telephone = "No Telephone";
        }
        public Person(string name, string address, string telephone)
        {
            Name = name;
            Address = address;
            Telephone = telephone;
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        public string Telephone
        {
            get
            {
                return _telephone;
            }
            set
            {
                _telephone = value;
            }
        }
    }
}
