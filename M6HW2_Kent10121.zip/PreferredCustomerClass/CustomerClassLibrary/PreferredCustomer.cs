﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerClassLibrary
{
    public class PreferredCustomer : Customer
    {
        // Fields
        private int _spentAmount;
        private double _discount;

        // Constructors
        public PreferredCustomer()
        {
            SpentAmount = 0;
            Discount = 0;
        }
        public PreferredCustomer(string name, string address, string telephone, int customNum, bool mailing, int spentAmount, int discount)
            : base(name, address, telephone, customNum, mailing)
        {
            SpentAmount = spentAmount;
            Discount = discount;
        }
        public int SpentAmount { get; set; }
        public double Discount { get; set; }
        public double GetDiscountPercent()
        {
            if (SpentAmount < 500)
            {
                Discount = 0;
            }
            else if (SpentAmount >= 500 && SpentAmount < 1000)
            {
                Discount = 100 * .05;
            }
            else if (SpentAmount >= 1000 && SpentAmount < 1500)
            {
                Discount = 100 * .06;
            }
            else if (SpentAmount >= 1500 && SpentAmount < 2000)
            {
                Discount = 100 * .07;
            }
            else if (SpentAmount >= 2000)
            {
                Discount = 100 * .10;
            }
            return  Discount;
        }
    }
}
