﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Math
    {
        public static double FallingDistance(double seconds)
        {
            const double g = 9.8;
            double distance = 0.5 * g * (seconds * seconds);

            return distance;
        }
    }
}
