﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallDistance
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables
            double distance;
            double seconds;

            Console.WriteLine("This is to display the Falling Distance");
            seconds = Input("How many seconds did the object travel? ");
            distance = FallingDistance(seconds);
            Console.WriteLine($"The object traveled {distance} meters in {seconds} seconds");
            Console.ReadLine();
        }
        static double Input(string prompt)
        {
            Console.Write(prompt);
            return Convert.ToDouble(Console.ReadLine());
        }
        public static double FallingDistance(double seconds)
        {
            const double g = 9.8;
            double distance = 0.5 * g * (seconds * seconds);

            return distance;
        }
    }
}
    
