﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * Kent Je'Von 
 * CSC - 153
 * 2/10/2020
 */
namespace ConsoleUI
{
    class Program
    {
        
        static void Main(string[] args)
        {
            // Input for the user and for the loop
            string input;
            bool exit = false;
            // Constant
            const int SIZE = 5;

            int nameIndex = 0; 
            int phoneIndex = 0; 
            int ageIndex = 0;
            // Arrays
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            // Process 
            do
            {
                Console.WriteLine("1. Enter employee's name.");
                Console.WriteLine("2. Enter employee's phone number.");
                Console.WriteLine("3. Enter employee's age.");
                Console.WriteLine("4. Display employee information.");
                Console.WriteLine("5. Display average age of employees.");
                Console.WriteLine("6. Exit");
                Console.Write("--> ");
                // User's input
                input = Console.ReadLine();

                // Switch to the process
                switch(input)
                {
                    case "1":
                        Console.Write("Enter employee's name: ");
                        input = Console.ReadLine();
                        employeeNames[nameIndex] = input; 
                        nameIndex++;
                        Console.WriteLine("");
                        break;
                    case "2":
                        Console.Write("Enter employee's phone number: ");
                        input = Console.ReadLine();
                        employeePhone[phoneIndex] = input;
                        phoneIndex++;
                        Console.WriteLine("");
                        break;
                    case "3":
                        int number = 0;
                        Console.Write("Enter employee's age: ");
                        input = Console.ReadLine();

                        if(int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                        }
                        else
                        {
                            Console.WriteLine("Not a valid number");
                        }
                        Console.WriteLine("");
                        break;
                    case "4":
                        for(int index = 0; index < employeeAge.Count; index++)
                        {
                            Console.WriteLine($"Employee Name - {employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($"Employee Age - {employeeAge[index].ToString()}");
                            Console.WriteLine("");
                        }
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice!");
                        break;

                }
            } while (exit == false);
        }
    }
}
