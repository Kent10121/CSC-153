﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Weapon
    {
        // Fields
        private string _name;
        private string _type;
        private int _damage;
        // Default Constructor
        public Weapon()
        {
            Name = "";
            Type = "";
            Damage = 0;
        }
        // Custom Constructor
        public Weapon(string name, string type, int damage)
        {
            Name = name;
            Type = type;
            Damage = damage;
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }
        // Auto Property
        public int Damage { get; set;}
    }
}
