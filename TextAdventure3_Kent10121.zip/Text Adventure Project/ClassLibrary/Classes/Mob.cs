﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Mob
    {
        // Fields
        private string _name;
        // Default Constructor
        public Mob()
        {
            Name = "";
            Health = 0;
            AttackDamage = 0;
        }
        // Custom Constructor
        public Mob(string name, int health, int attackDamage)
        {
            Name = name;
            Health = health;
            AttackDamage = attackDamage;
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        // Auto Properties
        public int Health { get; set; }
        public int AttackDamage { get; set; }
    }
}
