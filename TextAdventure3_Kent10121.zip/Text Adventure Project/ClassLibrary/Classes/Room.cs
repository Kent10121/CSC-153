﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Room
    {
        // Fields
        private string _name;
        private string _description;
        private string _exits;
        // Default Constructor
        public Room()
        {
            Name = "";
            Description = "";
            Exits = "No Exits";
        }
        // Custom Constructor
        public Room(string name, string description, string exits)
        {
            Name = name;
            Description = description;
            Exits = exits;
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public string Exits
        {
            get
            {
                return _exits;
            }
            set
            {
                _exits = value;
            }
        }
    }
}
