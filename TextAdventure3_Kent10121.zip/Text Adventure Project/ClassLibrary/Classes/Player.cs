﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Player
    {
        //Fields
        private string _name;
        private string _password;
        private string _class;
        private string _race;
        private int _health;
        private int _mana;
        // Default Constructor
        public Player()
        {
            Class = "No Class";
            Race = "No Race";
            Health = 0;
            Mana = 0;
        }
        // Custom Constructor
        public Player(string playerClass, string race, int health, int mana)
        {
            Class = playerClass;
            Race = race;
            Health = health;
            Mana = mana;
        }
        // Properties
        public string Class
        {
            get
            {
                return _class;
            }
            set
            {
                _class = value;
            }
        }
        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
        public int Health
        {
            get
            {
                return _health;
            }
            set
            {
                _health = value;
            }
        }
        public int Mana
        {
            get
            {
                return _mana;
            }
            set
            {
                _mana = value;
            }
        }
    }
}
