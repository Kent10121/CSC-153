﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Treasure
    {
        // Fields
        private string _name;
        private string _description;
        private int _price;
        // Default Constructor
        public Treasure()
        {
            Name = "";
            Description = "";
            Price = 0;
        }
        // Custom Constructor
        public Treasure(string name, string description, int price)
        {
            Name = name;
            Description = description;
            Price = price;
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public int Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
    }
}
