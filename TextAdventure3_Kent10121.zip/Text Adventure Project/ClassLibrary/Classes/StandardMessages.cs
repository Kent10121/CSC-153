﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Build Player\n2. Move North\n3. Move South\n4. Attack\n5. Exit";
        }
        public static string ShowPlayer(Player myPlayer)
        {
            return $"Player Class - {myPlayer.Class},\nPlayer Race - {myPlayer.Race},\n" +
                   $"Health - {myPlayer.Health},\nMana - {myPlayer.Mana}";
        }
    }
}
