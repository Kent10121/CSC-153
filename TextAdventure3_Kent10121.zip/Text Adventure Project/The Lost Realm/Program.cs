﻿/**
 * 4/4/2020
 * CSC 153
 * Kent Je'Von
 * This program will let you build your player
 * and the move to the next area and combat.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace The_Lost_Realm
{
    class Program
    {
        static void Main(string[] args)
        {
            // Array for Rooms
            Room[] rooms = {new Room("Arealia-Town", "The town where your safety is & you can talk to " +
                                      " innkeepers, merchants and townsfolk", "North - Woods"),
                             new Room("Woods", "The mysterious place of nature. BEWARE for wolves.", "North" +
                             " - Dungeon Entrance, South - Arealia-Town"),
                             new Room("Dungeon Entrance", "A strange place that leads to possibly a reward or" +
                             " dangerous area", "North - Eerie Room, South - Woods"),
                             new Room("Eerie Room", "A spooky room *gasp* could be a ghost in here", "North" +
                             " - Foggy Room, South - Dungeon Entrance"),
                             new Room("Foggy Room", "I can't see in here its really cloudy wonder what's in here",
                             "South - Eerie Room")};
            // List for Mobs
            List<Mob> mobs = new List<Mob>() { new Mob("Wolf", 20, 2),
                                               new Mob("Witch", 30, 8),
                                               new Mob("Goblin", 25, 6),
                                               new Mob("Troll", 20, 7),
                                               new Mob("Merchant", 100, 0)};
            Player myPlayer = new Player();
            int index = 0;
            Console.WriteLine("Welcome to The Lost Realm");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Main Menu");
            bool exit = false;
            
            do
            {
                Console.WriteLine($"Current name is - {rooms[index].Name}");
                Console.WriteLine(StandardMessages.DisplayMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        myPlayer = BuildPlayer.BuildAPlayer(myPlayer);
                        Console.WriteLine(StandardMessages.ShowPlayer(myPlayer));
                        break;
                    case "2":
                    case "north":
                    case "North":
                        {
                            GoNorth(ref  rooms, ref index);
                        }
                        break;
                    case "3":
                    case "south":
                    case "South":
                        {
                            GoSouth(ref rooms, ref index);
                        }
                        break;
                    case "4":
                    case "attack":
                    case "Attack":
                        {
                            ToAttack(ref mobs);
                        }
                        break;
                    case "5":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice.");
                        break;
                }
                Console.Write("Press the ENTER key to continue...");
                Console.ReadLine();
                Console.WriteLine();
            } while (exit == false);
        }
        public static void GoNorth(ref Room[] room, ref int index)
        {
            if (index < room.Length)
            {
                if (index != room.Length - 1)
                {
                    index++;
                    Console.WriteLine($"You moved to {room[index].Name}");
                }
                else
                {
                    Console.WriteLine("Can't go further more.");
                }
            }
        }
        public static void GoSouth(ref Room[] room, ref int index)
        {
            if (index > 0)
            {
                index--;
                Console.WriteLine($"You moved to {room[index].Name}");
            }
            else
            {
                Console.WriteLine("You cant go any further!");
            }
        }
        public static void ToAttack(ref List<Mob> mobs)
        {
            Random rand = new Random();
            Console.Write($"You have a hit point of ");
            Console.Write(rand.Next(1, 20));
            Console.WriteLine($" to {mobs[0].Name}");
        }
    }
}