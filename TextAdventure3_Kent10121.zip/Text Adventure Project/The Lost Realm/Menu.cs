﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace The_Lost_Realm
{
    public static class Menu
    {
        public static void MainMenu()
        {
            //Array for Rooms
            Room[] rooms = {new Room("Arealia-Town", "The town where your safety is & you can talk to " +
                                      " innkeepers, merchants and townsfolk", "North - Woods"),
                             new Room("Woods", "The mysterious place of nature. BEWARE for wolves.", "North" +
                             " - Dungeon Entrance, South - Arealia-Town"),
                             new Room("Dungeon Entrance", "A strange place that leads to possibly a reward or" +
                             " dangerous area", "North - Eerie Room, South - Woods"),
                             new Room("Eerie Room", "A spooky room *gasp* could be a ghost in here", "North" +
                             " - Foggy Room, South - Dungeon Entrance"),
                             new Room("Foggy Room", "I can't see in here its really cloudy wonder what's in here",
                             "South - Eerie Room")};
            // Array for Weapons
            Weapon[] weapons = {new Weapon("Handcrafted Axe", "Blunt/Slash", 6),
                                new Weapon("Wooden Mace","Blunt", 11),
                                new Weapon("Wooden Bow","Piercing/Ranged", 8),
                                new Weapon("Magical Staff","Magic/Blunt", 10)};
            // Array for Potions
            Potion[] potions = {new Potion("Potion of Healing", "This potion heals up to 25 points of health",
                                 25, 0),
                                new Potion("Potion of Mana", "This potion heals up to 25 points of mana", 0, 25)};
            // Array for Treasures
            Treasure[] treasures = {new Treasure("Golden Handclaw", "This claw is a very rare item to find" +
                " keep this safe with you and make sure goblins dont touch it.", 145),
                               new Treasure("Titanium Titan", "This titanium Titan is a special item it needs " +
                               "the best wizard to unlock it to become your companion in a bigger form", 5000),
                               new Treasure("Goblin Golden Eye", "This is to prove you killed the biggest " +
                               "ad baddest goblin in the land and he was a pain. You can sell this item or sell it " +
                               "for gold", 1500)};
            // List for Items
            List<Item> items = new List<Item>() { new Item("Fur", "This is used for crafting and you got it from" +
                " killing a Wolf or Troll", 15, 0),
                               new Item("Gold Coins", "Current currency", 1, 1),
                               new Item("Wolf Meat", "This can be used for crafting or cooking in the world, this " +
                               "provides a good source of health if cooked", 8, 0),
                               new Item("Arrows", "These are used for ammo for your Bow", 5, 0)};
            // List for Mobs
            List<Mob> mobs = new List<Mob>() { new Mob("Wolf", 20, 2),
                                               new Mob("Witch", 30, 8),
                                               new Mob("Goblin", 25, 6),
                                               new Mob("Troll", 20, 7),
                                               new Mob("Merchant", 100, 0)};
            string choice;
            Console.WriteLine("Welcome to The Lost Realm");
            Console.WriteLine("-------------------------");
             do
             {
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Display Rooms");
                Console.WriteLine("2. Display Weapons");
                Console.WriteLine("3. Display Potions");
                Console.WriteLine("4. Display Treasures");
                Console.WriteLine("5. Display Items");
                Console.WriteLine("6. Display Mobs");
                Console.WriteLine("7. Exit");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        foreach (Room room in rooms)
                        {
                            Console.WriteLine(room.Name);
                        }
                        break;
                    case "2":
                        foreach (Weapon weapon in weapons)
                        {
                            Array.Sort(weapons);
                            Console.WriteLine(weapon.Name);
                        }
                        break;
                    case "3":
                        foreach (Potion potion in potions)
                        {
                            Console.WriteLine(potion.Name);
                        }
                        break;
                    case "4":
                        foreach (Treasure treasure in treasures)
                        {
                            Console.WriteLine(treasure.Name);
                        }
                        break;
                    case "5":
                        foreach (Item item in items)
                        {
                            Console.WriteLine(item.Name);
                        }
                        break;
                    case "6":
                        foreach (Mob mob in mobs)
                        {
                            Console.WriteLine(mob.Name);
                        }
                        break;
                    case "7":
                        break;
                    default:
                        Console.WriteLine("Not a valid choice.");
                        break;
                }
                Console.Write("Press the ENTER key to continue...");
                
                Console.ReadLine();
                Console.WriteLine();
             } while (choice != "7");
        }
    }
}
