﻿/**
 * 2/1/2020
 * CSC 153
 * Kent Je'Von
 * This program is going to display an array of values.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TotalSales
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The values of the array are shown below");
            double[] values = new double[7];  // The size of the array
            values[0] = 1245.67;
            values[1] = 1189.55;
            values[2] = 1098.72;
            values[3] = 1456.88;
            values[4] = 2109.34;
            values[5] = 1987.55;
            values[6] = 1872.36;
            foreach (double element in values)
            {
                Console.WriteLine(element);
            }
            Console.ReadLine();
        }
    }
}
