﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;
/**
* 4/15/2020
* CSC 153
* Je'Von Kent
* This program displays the class of a customer 
*  within the person class inheritance
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer customer1 = new Customer();
            customer1.Name = "Jim";
            customer1.Address = "143 Lakeway Ave.";
            customer1.Telephone = "9106452347";
            customer1.CustomerNum = 984;
            customer1.MailingList = true;

            Console.WriteLine(StandardMessages.ShowCustomer(customer1));
            Console.ReadLine();
        }
    }
}
