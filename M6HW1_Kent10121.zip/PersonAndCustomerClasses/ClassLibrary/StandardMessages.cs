﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string ShowCustomer(Customer customer1)
        {
            return $"Name - {customer1.Name}\nAddress - {customer1.Address}\n" +
                $"Telephone - {customer1.Telephone}\nCustomerID - #{customer1.CustomerNum}";
        }
    }
}
