﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Customer : Person
    {
        // Fields
        private int _customNum;
        private bool _mailing;

        // Constructors
        public Customer()
        {
            CustomerNum = 0;
            MailingList = true;
        }
        public Customer(string name, string address, string telephone, int customNum, bool mailing)
            : base(name, address, telephone)
        {
            CustomerNum = customNum;
            MailingList = mailing;
        }
        public int CustomerNum
        {
            get
            {
                return _customNum;
            }
            set
            {
                _customNum = value;
            }
        }
        public bool MailingList
        {
            get
            {
                return _mailing;
            }
            set
            {
                _mailing = value;
            }
        }
    }
}
