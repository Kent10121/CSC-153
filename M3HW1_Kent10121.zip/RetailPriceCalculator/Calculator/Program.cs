﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * Kent Je'Von 
 * CSC - 153
 * 2/21/2020
 * This program is going to display input for the price of the 
   item and percent then covert it to the retail price.
 */

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        { 
            // Variables
            double wholesale;
            double markup;
            double retailPrice;

            Console.WriteLine("Welcome to the Retail Calculator.");
            wholesale = UserInput("What is the wholesale cost of the item $");
            markup = UserInput("What is markup percent of the item %");
            retailPrice = CalculateRetail(wholesale, markup);
            Console.WriteLine($"The retail price is ${retailPrice}");
            Console.ReadLine();
        }
        // The method to declare user input
        static double UserInput(string prompt)
        {
            System.Console.Write(prompt);
            return System.Convert.ToDouble(Console.ReadLine());

        } 
        // The method to calculate the inputs
        static double CalculateRetail(double wholesale, double markup)
        {
            double markupPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }
    }
}
