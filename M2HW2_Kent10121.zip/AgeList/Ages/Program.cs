﻿/*
 * Kent Je'Von
 * CSC-153
 * 2/9/2020
 * This program will show a menu to either exit or show ages and you can display the avergae of the numbers
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ages
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I have gave the user input to 4 numbers to display your inputs");
            Console.Write("Your first number is: ");
            int input = Convert.ToInt32(Console.ReadLine());
            Console.Write("Your second number is: ");
            int input2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Your third number is: ");
            int input3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Your last number is: ");
            int input4 = Convert.ToInt32(Console.ReadLine());
            List<int> ages = new List<int>();
            string choice;
            ages.Add(input);
            ages.Add(input2);
            ages.Add(input3);
            ages.Add(input4);

            do
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Display Ages");
                Console.WriteLine("2. Display Average");
                Console.WriteLine("3. Exit");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        foreach (var age in ages)
                        {
                            Console.WriteLine(age);

                        }
                        break;
                    case "2":
                        double sum = 0;
                        foreach (var number in ages)
                        {
                            sum += (double)number;
                        }
                        var average = sum / ages.Count;
                        Console.WriteLine("The average of numbers is: " + average);
                        break;
                    case "3":
                        break;
                    default:
                        Console.WriteLine("Not a choice.");
                        break;
                }
            } while (choice != "3");
        }
    }
}
