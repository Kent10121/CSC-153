﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
    public class RetailItem
    {
        // Fields
        private string _description;
        private int _units;
        private string _price;

        // Constructors
        public RetailItem()
        {
            Description = "No Descrip";
            UnitsOnHand = 0;
            Price = "No Price";
        }
        // Custom Constructor
        public RetailItem(string descript, int units, string price)
        {
            Description = descript;
            UnitsOnHand = units;
            Price = price;
        }
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public int UnitsOnHand
        {
            get
            {
                return _units;
            }
            set
            {
                _units = value;
            }
        }
        public string Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
    }
}
