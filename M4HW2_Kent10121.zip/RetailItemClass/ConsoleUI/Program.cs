﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailItemClassLibrary;
/**
 * 3/29/2020
 * CSC 153
 * Kent Je'Von
 * This program will show the description 
 * of a class with the item, units & price.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        { 
            // List
            List<RetailItem> items = new List<RetailItem>();
            // Items
            RetailItem item1 = new RetailItem()
            {
                Description = "Jacket",
                UnitsOnHand = 12,
                Price = "59.05"
            };
            RetailItem item2 = new RetailItem()
            {
                Description = "Jeans",
                UnitsOnHand = 40,
                Price = "34.95"
            };
            RetailItem item3 = new RetailItem()
            {
                Description = "Shirt",
                UnitsOnHand = 20,
                Price = "24.95"
            };
            items.Add(item1);
            items.Add(item2);
            items.Add(item3);
            foreach (RetailItem x in items)
            {
                Console.WriteLine($"Description - {x.Description} Units on Hand - {x.UnitsOnHand} Price - ${x.Price}");
            }
            Console.ReadLine();
        }
    }
}
